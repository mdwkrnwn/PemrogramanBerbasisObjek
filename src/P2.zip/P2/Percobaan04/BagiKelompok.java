package P2.Percobaan04;

public class BagiKelompok {
    public static void main(String[] args) {
        System.out.println("awal program");

        int jumlahMahasiswa = 32;
        int jumlahKelompok = 0;
        int anggotaPerKelompok = jumlahMahasiswa / jumlahKelompok;

        System.out.println(anggotaPerKelompok);
        System.out.println("akhir program");
    }
}
