package P12.Percobaan3;

import P12.Percobaan1.ElectricityBill;
import P12.Percobaan1.Employee;
import P12.Percobaan1.InternshipEmployee;
import P12.Percobaan1.Payable;
import P12.Percobaan1.PermanentEmployee;

public class Tester3 {
    public static void main(String[] args) {
        PermanentEmployee pEmp = new PermanentEmployee("Dedik", 500);

        InternshipEmployee iEmp = new InternshipEmployee("Sunarto", 5);

        ElectricityBill eBill = new ElectricityBill(5, "R-1");

        Employee[] e = { pEmp, iEmp };
        Payable[] p = { pEmp, eBill };

        // Baris berikut menyebabkan error jika diaktifkan:
        // Employee[] eBillArray = {pEmp, eBill};
    }
}
