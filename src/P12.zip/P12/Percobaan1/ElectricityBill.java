package P12.Percobaan1;


public class ElectricityBill implements Payable {
    private int kwh;
    private String category;

    public ElectricityBill(int kwh, String category) {
        this.kwh = kwh;
        this.category = category;
    }

    public int getKwh() {
        return kwh;
    }

    public void setKwh(int kwh) {
        this.kwh = kwh;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public int getPaymentAmount() {
        return kwh * getBasePrice();
    }

    public int getBasePrice() {
        int price = 0;

        switch (category) {
            case "R-1":
                price = 100;
                break;
            case "R-2":
                price = 200;
                break;
        }

        return price;
    }

    public String getBillInfo() {
        return "KWH = " + kwh + "\n"
                + "Category = " + category
                + "(" + getBasePrice() + " per KWH)\n";
    }
}
