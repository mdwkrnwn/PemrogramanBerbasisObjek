package P12.Tugas;

public class Tester {
    public static void main(String[] args) {
        WalkingZombie wz = new WalkingZombie(100, 1);
        JumpingZombie jz = new JumpingZombie(100, 2);
        Barrier b = new Barrier(100);

        Plant p = new Plant();

        System.out.println(wz.getZombieInfo());
        System.out.println();
        System.out.println(jz.getZombieInfo());
        System.out.println();
        System.out.println(b.getBarrierInfo());

        for (int i = 0; i < 4; i++) {
            wz.heal();
            jz.heal();

            p.doDestroy(wz);
            p.doDestroy(jz);
            p.doDestroy(b);
        }

        System.out.println();
        System.out.println(wz.getZombieInfo());
        System.out.println();
        System.out.println(jz.getZombieInfo());
        System.out.println();
        System.out.println(b.getBarrierInfo());
    }
}
