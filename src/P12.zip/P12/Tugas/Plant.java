package P12.Tugas;


public class Plant {

    public void doDestroy(Destroyable d) {
        d.destroyed();
    }
}
