package P12.Tugas;


public interface Destroyable {
    public void destroyed();
}
