package P12.Tugas;


public class JumpingZombie extends Zombie {

    public JumpingZombie(int health, int level) {
        super(health, level);
    }

    @Override
    public void heal() {
        switch (level) {
            case 1:
                health += 30;
                break;
            case 2:
                health += 40;
                break;
            case 3:
                health += 50;
                break;
        }
    }

    @Override
    public void destroyed() {
        health -= 1;
        if (health < 0) {
            health = 0;
        }
    }

    @Override
    public String getZombieInfo() {
        return "Jumping Zombie Data -\n"
                + super.getZombieInfo();
    }
}
