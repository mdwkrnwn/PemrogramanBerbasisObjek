package P11.Tugas;

import P11.Account;
import P11.Customer;

public class BusinessAccount extends Account {

    private static final double MINIMUM_BALANCE = 1000000.0;

    public BusinessAccount(
            String accountNumber,
            Customer owner,
            double balance) {

        super(accountNumber, owner, balance);
    }

    @Override
    protected boolean canWithdraw(double amount) {
        return amount > 0
                && (getBalance() - amount) >= MINIMUM_BALANCE;
    }

    @Override   
    public double monthlyFee() {
        return 0.0;
    }

    @Override
    public void printInfo() {
        super.printInfo();

        System.out.println("Account type: Business");
    }
}