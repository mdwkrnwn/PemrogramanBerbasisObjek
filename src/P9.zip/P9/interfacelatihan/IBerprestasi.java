package P9.interfacelatihan;

public interface IBerprestasi {
    public abstract void menjualKompetisi();
    public abstract void membuatPublikasiIlmiah();

    
}
